﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace DefiningClasses
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person()
        {
            this.Name = "No name";
            this.Age = 1;
        }
        public Person(int age) : this()
        {
            this.Age = age;
        }
        public Person(string name,int age) : this(age)
        {
            this.Name = name;
        }

    }
    class Family
    {
        public Person[] Persons { get; set; }
        public void AddMember(Person member)
        {

        }
        public Person GetOldestMember()
        {
            int highest_age = 0;
            if (Persons.Length == 0)
            {
                return null;
            }
            Person oldest = Persons[0];
            foreach (var person in Persons)
            {
                if (person.Age > highest_age)
                {
                    highest_age = person.Age;
                    oldest = person;
                }
            }
            return oldest;
        }
    }
    class StartUp
    {
        static void Main(string[] args)
        {
            int people_count = int.Parse(Console.ReadLine());
            Family family = new Family();
            family.Persons = new Person[people_count];
            for (int i = 0; i < people_count; i++)
            {
                var line = Console.ReadLine().Split(" ");
                var person =new Person(line[0], int.Parse(line[1]));
                family.Persons[i] = person; 
            }
            Person[] sorted_family = family.Persons.OrderBy(x => x.Name).ToArray();
            for (int i = 0; i < people_count; i++)
            {
                if (sorted_family[i].Age > 30)
                {
                    Console.WriteLine($"{sorted_family[i].Name} - {sorted_family[i].Age}");
                }
                
            }
        }
    }
}
